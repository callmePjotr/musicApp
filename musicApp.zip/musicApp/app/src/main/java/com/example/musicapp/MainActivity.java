package com.example.musicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    String pfad;
    File files[];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onSuchen(View v){
        EditText etPfad = (EditText)findViewById(R.id.pfad);
        pfad = etPfad.getText().toString();

        File dir = new File(pfad);
        files = dir.listFiles();

        if(files ==null){
            Toast toto = Toast.makeText(this,pfad,Toast.LENGTH_LONG);
            toto.show();
            return;
        }

        String datArray[] = new String[files.length];

        for (int i = 0; i< files.length;i++){
            datArray[i] = files[i].getName();
            if (files[i].isDirectory()){
                datArray[i] += " - DIR";

            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, datArray);
        ((ListView)findViewById(R.id.textFenster)).setAdapter(adapter);
    }

}


